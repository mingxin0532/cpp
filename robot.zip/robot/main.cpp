#include "KeyboardControl.h"
#include "PIDController.h"
#include <ncurses.h>
#include <fstream>
#include <string>
#include <iostream>

int main(){


	KeyboardControl Controller;
	while(!Controller.shouldQuit()){
		Controller.Communicate();

	}
	endwin();

/*	std::string filename ="PIDControllerInput.txt";
	std::ifstream infile;
	infile.open(filename);
	if(!infile.is_open()){
		std::cout<< "ERROR"<<std::endl;
	}

	double sollwert;
	double istwert;
	while(infile >> sollwert >> istwert){
		my_PID.CalculateU(sollwert,istwert);
		double u = my_PID.GetU();

		std::cout<< "sollwert:"<<sollwert<<"  istwert:"<<istwert<<" to answer:"<<u<<std::endl;
	}
	infile.close();
*/
	return 0;
}
