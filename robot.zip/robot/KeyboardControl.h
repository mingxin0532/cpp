#ifndef KEYBOARDCONTROL_H
#define KEYBOARDCONTROL_H
#include "InterfaceSIM.h"
#include "PIDController.h"
class KeyboardControl{
private:
	double v_soll[2];
	double v_ist[2];
	int my_outputSignals[2];
	bool quit_;
	InterfaceSIM  m_Interface;
	PIDcontroller right_PID;
	PIDcontroller left_PID;

public:
	KeyboardControl();
	~KeyboardControl();
	void Communicate();
	void step();
	void LimitSpeed();

	bool shouldQuit();
	const double* getTargetSpeed() const;
	const double* getRealSpeed() const;
	const int* getOutputSpeed() const;
	static KeyboardControl* transferPointer;
	static void transferFunction();

};


#endif
