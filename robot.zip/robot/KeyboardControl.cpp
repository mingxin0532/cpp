#include "KeyboardControl.h"
#include <ncurses.h>
#include <cmath>
#include <algorithm>

const double Max_Speed = 0.5;
const double Min_Speed = -0.5;
const double Linear_Increment = 0.01;
const double Trun_increment = 0.05;
KeyboardControl* KeyboardControl::transferPointer = nullptr;

KeyboardControl::KeyboardControl(){
	v_soll[0]=0.0;
	v_soll[1]=0.0;
	v_ist[0]=0.0;
	v_ist[1]=0.0;
	my_outputSignals[0]=1500;
	my_outputSignals[1]=1500;
	quit_=false;

	m_Interface.Initialize(0.04,&transferFunction);
	transferPointer = this;
	right_PID=PIDcontroller(500.0,1850.0,0.0,0.04);
	left_PID=PIDcontroller(500.0,1850.0,0.0,0.04);
}
KeyboardControl::~KeyboardControl(){

}


void KeyboardControl::step(){
	const double* measureSpeeds = m_Interface.GetInput();
	v_ist[0]=measureSpeeds[0];
	v_ist[1]=measureSpeeds[1];
	right_PID.CalculateU(v_soll[0],v_ist[0]);
	left_PID.CalculateU(v_soll[1],v_ist[1]);

	double u_right=right_PID.GetU();
	double u_leftt=left_PID.GetU();

	int outputSignals[2];
	outputSignals[0]= 1500+static_cast<int>(u_right);
	outputSignals[1]= 1500+static_cast<int>(u_leftt);
	outputSignals[0]= std::max(1000,std::min(2000,outputSignals[0]));
	outputSignals[1]= std::max(1000,std::min(2000,outputSignals[1]));

	my_outputSignals[0]=outputSignals[0];
	my_outputSignals[1]=outputSignals[1];

	m_Interface.SetOutputs(outputSignals);

}
void KeyboardControl::Communicate(){

	sigprocmask(SIG_UNBLOCK,&m_Interface.mask,nullptr);

	initscr();
	nodelay(stdscr,TRUE);
	noecho();
	curs_set(0);

	int key = getch();

	if(key != ERR){
		char lastkey=static_cast<char>(key);

		switch(lastkey){
		case 'w':
			v_soll[0]+=Linear_Increment;
			v_soll[1]+=Linear_Increment;
			break;
		case 's':
			v_soll[0]-=Linear_Increment;
			v_soll[1]-=Linear_Increment;
			break;
		case 'd':
			v_soll[0]-=Trun_increment;
			v_soll[1]+=Trun_increment;
			break;
		case 'a':
			v_soll[0]+=Trun_increment;
			v_soll[1]-=Trun_increment;
			break;
		case 'b':
			v_soll[0]=0.0;
			v_soll[1]=0.0;
			break;
		case 'q':
			v_soll[0]=0.0;
			v_soll[1]=0.0;
			quit_=true;
			break;
		}
		LimitSpeed();

		clear();
		const double* targetSpeeds = getTargetSpeed();
		const double* realSpeeds = getRealSpeed();
		const int* outputSignals = getOutputSpeed();
		printw("Target Speed: %+.3f m/s  %+.3f m/s",targetSpeeds[0],targetSpeeds[1]);
		printw("\nReal Speed: %+.3f m/s  %+.3f m/s",realSpeeds[0],realSpeeds[1]);
		printw("\nOutputSignal: %i us  %i us",outputSignals[0],outputSignals[1]);
	}

	sigprocmask(SIG_BLOCK,&m_Interface.mask,nullptr);
}
bool KeyboardControl::shouldQuit(){
	return quit_;
}
const double* KeyboardControl::getTargetSpeed() const{
	return v_soll;
}
const double* KeyboardControl::getRealSpeed() const{
	return v_ist;
}
const int* KeyboardControl::getOutputSpeed() const{
	return my_outputSignals;
}

void KeyboardControl::LimitSpeed(){

	v_soll[0]=std::max(Min_Speed,std::min(Max_Speed,v_soll[0]));
	v_soll[1]=std::max(Min_Speed,std::min(Max_Speed,v_soll[1]));
}



void KeyboardControl::transferFunction(){
	transferPointer->step();
}




